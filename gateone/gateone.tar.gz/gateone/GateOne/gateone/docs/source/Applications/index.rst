Gate One Applications
=====================

Gate One is more than just a web-based terminal.  It can be host to many other
applications as well.  These applications have their own documentation...

.. toctree::
    :maxdepth: 2

    terminal/index.rst
