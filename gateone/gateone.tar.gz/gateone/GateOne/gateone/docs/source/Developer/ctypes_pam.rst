.. _ctypes-pam:

:mod:`ctypes_pam.py` - PAM Authentication Module
================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone.auth.ctypes_pam
    :members:
    :private-members:
