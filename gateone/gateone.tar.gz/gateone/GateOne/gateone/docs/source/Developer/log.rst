:mod:`log.py` - Gate One Logging Module
=======================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone.core.log
    :members:
    :private-members:
