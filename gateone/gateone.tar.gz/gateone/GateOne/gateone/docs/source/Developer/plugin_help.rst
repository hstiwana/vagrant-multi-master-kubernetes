The Help Plugin
===============

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

JavaScript
----------

.. autojs:: ../plugins/help/static/help.js
    :members:
