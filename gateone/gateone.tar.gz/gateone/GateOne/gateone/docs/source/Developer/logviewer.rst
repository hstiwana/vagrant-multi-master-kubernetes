:mod:`logviewer.py` - Session Log Viewer
========================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: logviewer
    :members:
    :private-members:
