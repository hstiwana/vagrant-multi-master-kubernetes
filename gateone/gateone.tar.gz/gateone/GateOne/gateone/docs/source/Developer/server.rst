:mod:`server.py` - Gate One's Core Script
=========================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone.core.server
    :members:
    :private-members:
