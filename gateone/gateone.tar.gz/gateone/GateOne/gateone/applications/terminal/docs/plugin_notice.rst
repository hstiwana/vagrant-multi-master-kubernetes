The Notice Plugin
=================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

Python
------

.. automodule:: notice
    :members:
    :private-members:
