:mod:`app_terminal.py` - Gate One Terminal Application
======================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: app_terminal
    :members:
    :private-members:
