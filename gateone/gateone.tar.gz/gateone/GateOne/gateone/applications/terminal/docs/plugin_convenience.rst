.. _convenience-plugin:

The Convenience Plugin
======================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>


JavaScript
----------

.. autojs:: ../applications/terminal/plugins/convenience/static/convenience.js
    :members:
